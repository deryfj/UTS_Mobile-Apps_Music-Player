package umn.ac.musik;

import java.io.File;
import java.util.ArrayList;

public class Constant {
    public static String[] musicextension = {".mp3"};

    //all loaded files will be here
    public static ArrayList<File> allMediaList = new ArrayList<>();

}
