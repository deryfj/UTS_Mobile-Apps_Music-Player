package umn.ac.musik;

import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

public class PlayerActivity extends AppCompatActivity {

    Bundle songExtraData;
    ImageView prev, play, next;

}
