package umn.ac.musik;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button profil, login;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setTitle("Dery Frawijaya - 25733");
        setContentView(R.layout.activity_main);


        profil = (Button) findViewById(R.id.button_profil);
        login = (Button) findViewById(R.id.button_login);


        profil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openprofil();
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openlogin();
            }
        });


    }



    public void openprofil() {
        Intent intent = new Intent(this, ProfilActivity.class);
        startActivity(intent);
    }

    public void openlogin() {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }
}